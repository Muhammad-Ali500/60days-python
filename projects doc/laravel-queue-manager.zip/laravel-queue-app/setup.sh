#!/bin/bash

# ══════════════════════════════════════════════════
#   Laravel Queue Manager — Local Setup Script
# ══════════════════════════════════════════════════

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo ""
echo -e "${CYAN}${BOLD}══════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}   Laravel Queue Manager Setup        ${NC}"
echo -e "${CYAN}${BOLD}══════════════════════════════════════${NC}"
echo ""

# ── Check requirements ──────────────────────────────────
echo -e "${BLUE}▶ Checking requirements...${NC}"

if ! command -v php &> /dev/null; then
    echo -e "${RED}✗ PHP not found. Please install PHP 8.2+${NC}"
    exit 1
fi

PHP_VERSION=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
echo -e "${GREEN}✓ PHP $PHP_VERSION found${NC}"

if ! command -v composer &> /dev/null; then
    echo -e "${RED}✗ Composer not found. Install from https://getcomposer.org${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Composer found${NC}"

if ! command -v redis-cli &> /dev/null; then
    echo -e "${YELLOW}⚠ redis-cli not found. Install Redis:${NC}"
    echo "  Ubuntu/Debian: sudo apt install redis-server"
    echo "  macOS:         brew install redis"
    echo "  Windows:       https://github.com/microsoftarchive/redis/releases"
else
    echo -e "${GREEN}✓ Redis CLI found${NC}"
fi

# ── Install dependencies ───────────────────────────────
echo ""
echo -e "${BLUE}▶ Installing PHP dependencies...${NC}"
composer install --no-interaction

# ── Environment setup ──────────────────────────────────
echo ""
echo -e "${BLUE}▶ Setting up environment...${NC}"
if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${GREEN}✓ .env created${NC}"
else
    echo -e "${YELLOW}⚠ .env already exists, skipping${NC}"
fi

# ── Generate app key ───────────────────────────────────
echo ""
echo -e "${BLUE}▶ Generating application key...${NC}"
php artisan key:generate

# ── Create SQLite database ─────────────────────────────
echo ""
echo -e "${BLUE}▶ Creating SQLite database...${NC}"
mkdir -p database
touch database/database.sqlite
echo -e "${GREEN}✓ database/database.sqlite created${NC}"

# ── Run migrations ─────────────────────────────────────
echo ""
echo -e "${BLUE}▶ Running database migrations...${NC}"
php artisan migrate --force

# ── Set permissions ────────────────────────────────────
echo ""
echo -e "${BLUE}▶ Setting permissions...${NC}"
chmod -R 775 storage bootstrap/cache
echo -e "${GREEN}✓ Permissions set${NC}"

# ── Create log directories ─────────────────────────────
mkdir -p /tmp/supervisor-logs
echo -e "${GREEN}✓ Log directories created${NC}"

# ── Done ───────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}══════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}   Setup Complete! 🎉               ${NC}"
echo -e "${GREEN}${BOLD}══════════════════════════════════════${NC}"
echo ""
echo -e "${BOLD}Next steps:${NC}"
echo ""
echo -e "  1. Make sure Redis is running:"
echo -e "     ${CYAN}sudo service redis-server start${NC}  (Linux)"
echo -e "     ${CYAN}brew services start redis${NC}         (macOS)"
echo ""
echo -e "  2. Start the development server:"
echo -e "     ${CYAN}php artisan serve${NC}"
echo ""
echo -e "  3. Start queue workers (in a new terminal):"
echo -e "     ${CYAN}php artisan queue:work redis --queue=high,emails,reports,default,low${NC}"
echo ""
echo -e "  4. Or use Supervisor (recommended for production):"
echo -e "     ${CYAN}sudo supervisord -c supervisor/supervisord.conf${NC}"
echo ""
echo -e "  5. Open in browser:"
echo -e "     ${CYAN}http://localhost:8000${NC}"
echo ""
echo -e "  6. REST API:"
echo -e "     ${CYAN}http://localhost:8000/api/queue/stats${NC}"
echo ""
echo -e "${BLUE}For Docker deployment:${NC}"
echo -e "  ${CYAN}docker-compose up -d${NC}"
echo ""
