<?php

namespace App\Jobs;

use App\Models\QueueTask;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessQueueTask implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $timeout = 120;
    public int $backoff = 10;

    public function __construct(public QueueTask $task)
    {
        $this->onQueue($task->queue ?? 'default');
    }

    public function handle(): void
    {
        $this->task->update([
            'status' => 'processing',
            'started_at' => now(),
            'attempts' => $this->attempts(),
        ]);

        try {
            $result = $this->processTask();

            $this->task->update([
                'status' => 'completed',
                'result' => $result,
                'completed_at' => now(),
            ]);

            Log::info("Task #{$this->task->id} ({$this->task->name}) completed successfully.");
        } catch (\Exception $e) {
            $this->task->update([
                'status' => 'failed',
                'error_message' => $e->getMessage(),
                'completed_at' => now(),
            ]);

            Log::error("Task #{$this->task->id} failed: " . $e->getMessage());
            throw $e;
        }
    }

    private function processTask(): string
    {
        // Simulate different job types with different processing times
        switch ($this->task->type) {
            case 'email':
                sleep(rand(1, 3));
                return "Email sent to " . ($this->task->payload['recipient'] ?? 'user@example.com');

            case 'report':
                sleep(rand(2, 5));
                return "Report generated: " . ($this->task->payload['report_name'] ?? 'report') . ".pdf";

            case 'import':
                sleep(rand(3, 7));
                $rows = rand(100, 10000);
                return "Imported {$rows} rows from " . ($this->task->payload['filename'] ?? 'data.csv');

            case 'export':
                sleep(rand(2, 4));
                return "Exported data to " . ($this->task->payload['format'] ?? 'csv') . " format";

            case 'notification':
                sleep(rand(1, 2));
                return "Notification sent to " . ($this->task->payload['channel'] ?? 'all users');

            default:
                sleep(rand(1, 4));
                return "General task '{$this->task->name}' processed successfully";
        }
    }

    public function failed(\Throwable $exception): void
    {
        $this->task->update([
            'status' => 'failed',
            'error_message' => $exception->getMessage(),
            'completed_at' => now(),
        ]);

        Log::error("Job permanently failed for task #{$this->task->id}: " . $exception->getMessage());
    }
}
