<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class GenerateReportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 2;
    public int $timeout = 300;

    public function __construct(
        public string $reportName,
        public string $format = 'pdf'
    ) {
        $this->onQueue('reports');
    }

    public function handle(): void
    {
        sleep(rand(3, 6));
        Log::info("Report '{$this->reportName}' generated in {$this->format} format.");
    }
}
