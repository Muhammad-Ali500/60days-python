<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    public function __construct(
        public string $recipient,
        public string $subject,
        public string $body
    ) {
        $this->onQueue('emails');
    }

    public function handle(): void
    {
        // Simulate email sending
        sleep(2);
        Log::info("Email sent to {$this->recipient}: {$this->subject}");
    }
}
