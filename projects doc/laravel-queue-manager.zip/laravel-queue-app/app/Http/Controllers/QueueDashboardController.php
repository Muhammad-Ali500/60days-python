<?php

namespace App\Http\Controllers;

use App\Jobs\ProcessQueueTask;
use App\Models\QueueTask;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\DB;

class QueueDashboardController extends Controller
{
    public function index()
    {
        $stats = $this->getStats();
        $recentTasks = QueueTask::latest()->take(10)->get();
        return view('dashboard.index', compact('stats', 'recentTasks'));
    }

    private function getStats(): array
    {
        return [
            'total'      => QueueTask::count(),
            'pending'    => QueueTask::where('status', 'pending')->count(),
            'processing' => QueueTask::where('status', 'processing')->count(),
            'completed'  => QueueTask::where('status', 'completed')->count(),
            'failed'     => QueueTask::where('status', 'failed')->count(),
        ];
    }

    public function jobs(Request $request)
    {
        $query = QueueTask::latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('queue')) {
            $query->where('queue', $request->queue);
        }
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $tasks = $query->paginate(15)->withQueryString();
        $stats = $this->getStats();

        return view('jobs.index', compact('tasks', 'stats'));
    }

    public function create()
    {
        return view('jobs.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'        => 'required|string|max:255',
            'type'        => 'required|in:email,report,import,export,notification,general',
            'queue'       => 'required|in:default,emails,reports,imports,high,low',
            'priority'    => 'integer|min:0|max:10',
            'max_attempts'=> 'integer|min:1|max:10',
            'payload'     => 'nullable|array',
        ]);

        $task = QueueTask::create([
            'name'         => $validated['name'],
            'type'         => $validated['type'],
            'queue'        => $validated['queue'],
            'priority'     => $validated['priority'] ?? 0,
            'max_attempts' => $validated['max_attempts'] ?? 3,
            'status'       => 'pending',
            'payload'      => $validated['payload'] ?? [],
        ]);

        ProcessQueueTask::dispatch($task);

        return redirect()->route('jobs.index')
            ->with('success', "Job \"{$task->name}\" dispatched successfully to the {$task->queue} queue!");
    }

    public function show(QueueTask $task)
    {
        return view('jobs.show', compact('task'));
    }

    public function retry(QueueTask $task)
    {
        if (!$task->isFailed()) {
            return back()->with('error', 'Only failed jobs can be retried.');
        }

        $task->update([
            'status'        => 'pending',
            'error_message' => null,
            'attempts'      => 0,
            'started_at'    => null,
            'completed_at'  => null,
        ]);

        ProcessQueueTask::dispatch($task);

        return back()->with('success', "Job \"{$task->name}\" has been re-dispatched.");
    }

    public function destroy(QueueTask $task)
    {
        $task->delete();
        return redirect()->route('jobs.index')->with('success', 'Job deleted successfully.');
    }

    public function bulkAction(Request $request)
    {
        $request->validate([
            'action'  => 'required|in:delete,retry',
            'task_ids'=> 'required|array',
        ]);

        $tasks = QueueTask::whereIn('id', $request->task_ids)->get();

        if ($request->action === 'delete') {
            QueueTask::whereIn('id', $request->task_ids)->delete();
            return back()->with('success', count($request->task_ids) . " job(s) deleted.");
        }

        if ($request->action === 'retry') {
            $retried = 0;
            foreach ($tasks as $task) {
                if ($task->isFailed()) {
                    $task->update([
                        'status' => 'pending',
                        'error_message' => null,
                        'attempts' => 0,
                        'started_at' => null,
                        'completed_at' => null,
                    ]);
                    ProcessQueueTask::dispatch($task);
                    $retried++;
                }
            }
            return back()->with('success', "{$retried} failed job(s) re-dispatched.");
        }

        return back()->with('error', 'Unknown action.');
    }
}
