<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\ProcessQueueTask;
use App\Models\QueueTask;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class QueueApiController extends Controller
{
    public function stats(): JsonResponse
    {
        $stats = [
            'total'      => QueueTask::count(),
            'pending'    => QueueTask::where('status', 'pending')->count(),
            'processing' => QueueTask::where('status', 'processing')->count(),
            'completed'  => QueueTask::where('status', 'completed')->count(),
            'failed'     => QueueTask::where('status', 'failed')->count(),
        ];

        $byType = QueueTask::selectRaw('type, count(*) as count')
            ->groupBy('type')
            ->pluck('count', 'type');

        $byQueue = QueueTask::selectRaw('queue, count(*) as count')
            ->groupBy('queue')
            ->pluck('count', 'queue');

        return response()->json([
            'stats'    => $stats,
            'by_type'  => $byType,
            'by_queue' => $byQueue,
        ]);
    }

    public function jobs(Request $request): JsonResponse
    {
        $query = QueueTask::latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $jobs = $query->paginate(20);
        return response()->json($jobs);
    }

    public function show(QueueTask $task): JsonResponse
    {
        return response()->json($task);
    }

    public function dispatch(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name'  => 'required|string|max:255',
            'type'  => 'required|in:email,report,import,export,notification,general',
            'queue' => 'required|in:default,emails,reports,imports,high,low',
        ]);

        $task = QueueTask::create([
            'name'    => $validated['name'],
            'type'    => $validated['type'],
            'queue'   => $validated['queue'],
            'status'  => 'pending',
            'payload' => $request->input('payload', []),
        ]);

        ProcessQueueTask::dispatch($task);

        return response()->json([
            'message' => 'Job dispatched successfully.',
            'task'    => $task,
        ], 201);
    }

    public function retry(QueueTask $task): JsonResponse
    {
        if (!$task->isFailed()) {
            return response()->json(['message' => 'Only failed tasks can be retried.'], 422);
        }

        $task->update([
            'status'        => 'pending',
            'error_message' => null,
            'attempts'      => 0,
            'started_at'    => null,
            'completed_at'  => null,
        ]);

        ProcessQueueTask::dispatch($task);

        return response()->json(['message' => 'Task re-dispatched.', 'task' => $task->fresh()]);
    }

    public function destroy(QueueTask $task): JsonResponse
    {
        $task->delete();
        return response()->json(['message' => 'Task deleted.']);
    }
}
