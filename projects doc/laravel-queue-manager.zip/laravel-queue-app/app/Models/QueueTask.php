<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class QueueTask extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'type',
        'status',
        'queue',
        'priority',
        'payload',
        'result',
        'error_message',
        'attempts',
        'max_attempts',
        'started_at',
        'completed_at',
    ];

    protected $casts = [
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
        'payload' => 'array',
    ];

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    public function isProcessing(): bool
    {
        return $this->status === 'processing';
    }

    public function isCompleted(): bool
    {
        return $this->status === 'completed';
    }

    public function isFailed(): bool
    {
        return $this->status === 'failed';
    }

    public function getDurationAttribute(): ?string
    {
        if ($this->started_at && $this->completed_at) {
            $seconds = $this->started_at->diffInSeconds($this->completed_at);
            if ($seconds < 60) return "{$seconds}s";
            $minutes = floor($seconds / 60);
            $secs = $seconds % 60;
            return "{$minutes}m {$secs}s";
        }
        return null;
    }

    public function scopeByStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    public function scopeByType($query, string $type)
    {
        return $query->where('type', $type);
    }

    public function scopeByQueue($query, string $queue)
    {
        return $query->where('queue', $queue);
    }
}
