<?php

use App\Http\Controllers\Api\QueueApiController;
use Illuminate\Support\Facades\Route;

Route::prefix('queue')->name('api.queue.')->group(function () {
    Route::get('/stats', [QueueApiController::class, 'stats'])->name('stats');
    Route::get('/jobs', [QueueApiController::class, 'jobs'])->name('jobs');
    Route::post('/jobs', [QueueApiController::class, 'dispatch'])->name('dispatch');
    Route::get('/jobs/{task}', [QueueApiController::class, 'show'])->name('show');
    Route::post('/jobs/{task}/retry', [QueueApiController::class, 'retry'])->name('retry');
    Route::delete('/jobs/{task}', [QueueApiController::class, 'destroy'])->name('destroy');
});
