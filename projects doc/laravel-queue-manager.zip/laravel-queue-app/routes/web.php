<?php

use App\Http\Controllers\QueueDashboardController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('dashboard');
});

Route::get('/dashboard', [QueueDashboardController::class, 'index'])->name('dashboard');

Route::prefix('jobs')->name('jobs.')->group(function () {
    Route::get('/', [QueueDashboardController::class, 'jobs'])->name('index');
    Route::get('/create', [QueueDashboardController::class, 'create'])->name('create');
    Route::post('/', [QueueDashboardController::class, 'store'])->name('store');
    Route::get('/{task}', [QueueDashboardController::class, 'show'])->name('show');
    Route::post('/{task}/retry', [QueueDashboardController::class, 'retry'])->name('retry');
    Route::delete('/{task}', [QueueDashboardController::class, 'destroy'])->name('destroy');
    Route::post('/bulk-action', [QueueDashboardController::class, 'bulkAction'])->name('bulk-action');
});
