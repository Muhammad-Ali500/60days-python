# 🚀 Laravel Queue Manager

A complete **Laravel 11** queue management system with **Redis**, **Supervisor**, and a beautiful frontend dashboard.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| **Dashboard** | Real-time stats, progress bars, quick-dispatch form |
| **Job Management** | Create, view, retry, delete jobs |
| **Multiple Queues** | `default`, `emails`, `reports`, `imports`, `high`, `low` |
| **Job Types** | Email, Report, Import, Export, Notification, General |
| **Redis Backend** | All queues powered by Redis for speed and reliability |
| **Supervisor** | Preconfigured workers for every queue |
| **REST API** | Full JSON API at `/api/queue/*` |
| **Bulk Actions** | Delete or retry multiple jobs at once |
| **Filtering** | Filter by status, type, queue, or name search |
| **Auto-Refresh** | Dashboard refreshes every 10 seconds |
| **Docker** | Full Docker Compose stack included |

---

## 📋 Requirements

- PHP **8.2+**
- Composer
- Redis Server
- Supervisor (for production)
- SQLite (default) or MySQL/PostgreSQL

---

## 🛠️ Quick Start (Local)

### 1. Install dependencies
```bash
composer install
```

### 2. Run the setup script
```bash
bash setup.sh
```

### 3. Start Redis
```bash
# Ubuntu / Debian
sudo service redis-server start

# macOS
brew services start redis

# Windows — download from:
# https://github.com/microsoftarchive/redis/releases
```

### 4. Verify Redis connection
```bash
redis-cli ping
# Should return: PONG
```

### 5. Start the web server
```bash
php artisan serve
# App runs at http://localhost:8000
```

### 6. Start queue workers (new terminal)
```bash
# All queues at once:
php artisan queue:work redis --queue=high,emails,reports,imports,default,low

# Or individual queue:
php artisan queue:work redis --queue=emails --sleep=3 --tries=3
```

### 7. Seed sample data (optional)
```bash
php artisan db:seed
```

---

## 🐳 Docker Setup (Recommended)

```bash
docker-compose up -d
```

This starts:
- **App** (PHP-FPM + Supervisor workers)
- **Nginx** on port `8000`
- **Redis** on port `6379`
- **Redis Commander UI** on port `8081`

Open: http://localhost:8000

---

## 🖥️ Supervisor Setup (Production)

### Install Supervisor
```bash
sudo apt install supervisor
```

### Copy configuration
```bash
sudo cp supervisor/supervisord.conf /etc/supervisor/conf.d/laravel-queue.conf
```

### Update paths in the config
Edit `/etc/supervisor/conf.d/laravel-queue.conf` and change:
```
/var/www/html → /path/to/your/project
```

### Load and start
```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start all
```

### Check status
```bash
sudo supervisorctl status
```

---

## 📡 REST API

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET`  | `/api/queue/stats` | Queue statistics |
| `GET`  | `/api/queue/jobs` | List jobs (paginated) |
| `POST` | `/api/queue/jobs` | Dispatch a new job |
| `GET`  | `/api/queue/jobs/{id}` | Get job details |
| `POST` | `/api/queue/jobs/{id}/retry` | Retry failed job |
| `DELETE` | `/api/queue/jobs/{id}` | Delete a job |

### Example: Dispatch via API
```bash
curl -X POST http://localhost:8000/api/queue/jobs \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Send Newsletter",
    "type": "email",
    "queue": "emails",
    "payload": {"recipient": "user@example.com"}
  }'
```

---

## 📁 Project Structure

```
laravel-queue-app/
├── app/
│   ├── Http/Controllers/
│   │   ├── QueueDashboardController.php   # Web controller
│   │   └── Api/QueueApiController.php     # REST API controller
│   ├── Jobs/
│   │   ├── ProcessQueueTask.php           # Main job handler
│   │   ├── SendEmailJob.php               # Email job
│   │   └── GenerateReportJob.php          # Report job
│   └── Models/
│       └── QueueTask.php                  # Job tracking model
├── database/migrations/                   # DB schema
├── resources/views/
│   ├── layouts/app.blade.php              # Master layout
│   ├── dashboard/index.blade.php          # Dashboard
│   └── jobs/                             # Job CRUD views
├── routes/
│   ├── web.php                            # Web routes
│   └── api.php                            # API routes
├── supervisor/
│   └── supervisord.conf                   # Supervisor config
├── docker/
│   ├── Dockerfile                         # App container
│   └── nginx.conf                         # Nginx config
├── docker-compose.yml                     # Full stack
└── setup.sh                               # Local setup script
```

---

## 🔧 Available Artisan Commands

```bash
# Queue commands
php artisan queue:work                     # Start worker
php artisan queue:listen                   # Listen mode (development)
php artisan queue:failed                   # List failed jobs
php artisan queue:retry all                # Retry all failed jobs
php artisan queue:flush                    # Flush failed jobs
php artisan queue:monitor redis:default    # Monitor queue

# Cache
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan cache:clear

# Database
php artisan migrate
php artisan db:seed
php artisan migrate:fresh --seed
```

---

## 🌐 Web Routes

| Route | Description |
|-------|-------------|
| `GET /` | Redirects to dashboard |
| `GET /dashboard` | Main dashboard |
| `GET /jobs` | All jobs with filtering |
| `GET /jobs/create` | Dispatch form |
| `POST /jobs` | Store & dispatch job |
| `GET /jobs/{id}` | Job detail |
| `POST /jobs/{id}/retry` | Retry job |
| `DELETE /jobs/{id}` | Delete job |
| `POST /jobs/bulk-action` | Bulk delete/retry |

---

## ⚙️ Environment Variables

```env
# Queue
QUEUE_CONNECTION=redis

# Redis
REDIS_CLIENT=predis
REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

# Database (SQLite default, switch to MySQL if needed)
DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
```

---

## 📄 License

MIT License — use freely in your projects.
