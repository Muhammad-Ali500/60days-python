<?php

namespace Database\Seeders;

use App\Models\QueueTask;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $types  = ['email','report','import','export','notification','general'];
        $queues = ['default','emails','reports','imports','high','low'];
        $statuses = ['pending','processing','completed','completed','completed','failed'];

        $samples = [
            ['name' => 'Send Welcome Email to John', 'type' => 'email', 'queue' => 'emails', 'payload' => ['recipient' => 'john@example.com']],
            ['name' => 'Generate Monthly Sales Report', 'type' => 'report', 'queue' => 'reports', 'payload' => ['report_name' => 'Monthly Sales']],
            ['name' => 'Import Customer CSV', 'type' => 'import', 'queue' => 'imports', 'payload' => ['filename' => 'customers.csv']],
            ['name' => 'Export Analytics Data', 'type' => 'export', 'queue' => 'default', 'payload' => ['format' => 'xlsx']],
            ['name' => 'Send Push Notifications', 'type' => 'notification', 'queue' => 'high', 'payload' => ['channel' => 'mobile-users']],
            ['name' => 'Process Payment Batch', 'type' => 'general', 'queue' => 'high', 'payload' => []],
            ['name' => 'Send Password Reset Email', 'type' => 'email', 'queue' => 'emails', 'payload' => ['recipient' => 'jane@example.com']],
            ['name' => 'Generate Invoice PDF', 'type' => 'report', 'queue' => 'reports', 'payload' => ['report_name' => 'Invoice #1042']],
            ['name' => 'Sync Product Inventory', 'type' => 'import', 'queue' => 'default', 'payload' => ['filename' => 'inventory.csv']],
            ['name' => 'Send Newsletter', 'type' => 'notification', 'queue' => 'low', 'payload' => ['channel' => 'subscribers']],
        ];

        foreach ($samples as $i => $sample) {
            $status = $statuses[array_rand($statuses)];
            QueueTask::create(array_merge($sample, [
                'status'       => $status,
                'priority'     => rand(0, 10),
                'max_attempts' => 3,
                'attempts'     => $status === 'failed' ? 3 : ($status === 'completed' ? 1 : 0),
                'result'       => $status === 'completed' ? 'Task completed successfully.' : null,
                'error_message'=> $status === 'failed' ? 'Connection timeout after 90 seconds.' : null,
                'started_at'   => in_array($status, ['processing','completed','failed']) ? now()->subMinutes(rand(1,60)) : null,
                'completed_at' => in_array($status, ['completed','failed']) ? now()->subMinutes(rand(0,30)) : null,
                'created_at'   => now()->subHours(rand(1,24)),
            ]));
        }
    }
}
