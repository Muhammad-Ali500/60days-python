<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('queue_tasks', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('type')->default('general'); // email, report, import, export, general
            $table->string('status')->default('pending'); // pending, processing, completed, failed
            $table->string('queue')->default('default');
            $table->integer('priority')->default(0);
            $table->text('payload')->nullable();
            $table->text('result')->nullable();
            $table->text('error_message')->nullable();
            $table->integer('attempts')->default(0);
            $table->integer('max_attempts')->default(3);
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('queue_tasks');
        Schema::dropIfExists('sessions');
    }
};
