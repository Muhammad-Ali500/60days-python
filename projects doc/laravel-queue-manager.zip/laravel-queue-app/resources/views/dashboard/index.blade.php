@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')
@section('page-subtitle', 'Real-time queue monitoring')

@section('content')

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-layer-group"></i></div>
        <div>
            <div class="stat-number">{{ $stats['total'] }}</div>
            <div class="stat-label">Total Jobs</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-clock"></i></div>
        <div>
            <div class="stat-number">{{ $stats['pending'] }}</div>
            <div class="stat-label">Pending</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-spinner"></i></div>
        <div>
            <div class="stat-number">{{ $stats['processing'] }}</div>
            <div class="stat-label">Processing</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-circle-check"></i></div>
        <div>
            <div class="stat-number">{{ $stats['completed'] }}</div>
            <div class="stat-label">Completed</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-triangle-exclamation"></i></div>
        <div>
            <div class="stat-number">{{ $stats['failed'] }}</div>
            <div class="stat-label">Failed</div>
        </div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 380px;gap:20px;">

    <!-- Recent Jobs -->
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-clock-rotate-left" style="color:var(--primary);margin-right:6px;"></i>Recent Jobs</span>
            <a href="{{ route('jobs.index') }}" class="btn btn-outline btn-sm">View All</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Queue</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($recentTasks as $task)
                    <tr>
                        <td style="font-weight:600;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $task->name }}</td>
                        <td><span class="badge badge-{{ $task->type }}">{{ $task->type }}</span></td>
                        <td><span class="queue-tag"><i class="fas fa-server" style="font-size:9px;"></i>{{ $task->queue }}</span></td>
                        <td>
                            <span class="badge badge-{{ $task->status }}">
                                @if($task->status === 'processing')<i class="fas fa-spinner fa-spin" style="font-size:9px;"></i>@endif
                                {{ $task->status }}
                            </span>
                        </td>
                        <td style="color:var(--gray-400);font-size:12px;">{{ $task->created_at->diffForHumans() }}</td>
                        <td><a href="{{ route('jobs.show', $task) }}" class="btn btn-outline btn-sm"><i class="fas fa-eye"></i></a></td>
                    </tr>
                    @empty
                    <tr><td colspan="6" class="empty"><i class="fas fa-inbox"></i><br>No jobs yet</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Right Panel -->
    <div style="display:flex;flex-direction:column;gap:16px;">

        <!-- Progress Card -->
        <div class="card card-body">
            <div class="card-title" style="margin-bottom:16px;"><i class="fas fa-chart-bar" style="color:var(--primary);margin-right:6px;"></i>Success Rate</div>
            @php
                $total = max($stats['completed'] + $stats['failed'], 1);
                $rate  = $stats['completed'] > 0 ? round(($stats['completed'] / $total) * 100) : 0;
            @endphp
            <div style="font-size:36px;font-weight:800;color:var(--gray-900);margin-bottom:6px;">{{ $rate }}%</div>
            <div class="progress" style="margin-bottom:8px;">
                <div class="progress-bar progress-success" style="width:{{ $rate }}%"></div>
            </div>
            <div style="font-size:12px;color:var(--gray-400);">{{ $stats['completed'] }} completed / {{ $stats['failed'] }} failed</div>
        </div>

        <!-- Quick Dispatch -->
        <div class="card card-body">
            <div class="card-title" style="margin-bottom:14px;"><i class="fas fa-bolt" style="color:var(--warning);margin-right:6px;"></i>Quick Dispatch</div>
            <form action="{{ route('jobs.store') }}" method="POST">
                @csrf
                <input type="hidden" name="max_attempts" value="3">
                <div class="form-group">
                    <input type="text" class="form-control" name="name" placeholder="Job name..." required>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">
                    <select name="type" class="form-control">
                        <option value="general">General</option>
                        <option value="email">Email</option>
                        <option value="report">Report</option>
                        <option value="import">Import</option>
                        <option value="export">Export</option>
                        <option value="notification">Notification</option>
                    </select>
                    <select name="queue" class="form-control">
                        <option value="default">Default</option>
                        <option value="emails">Emails</option>
                        <option value="reports">Reports</option>
                        <option value="high">High</option>
                        <option value="low">Low</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <i class="fas fa-paper-plane"></i> Dispatch
                </button>
            </form>
        </div>

        <!-- System Info -->
        <div class="card card-body">
            <div class="card-title" style="margin-bottom:14px;"><i class="fas fa-server" style="color:var(--info);margin-right:6px;"></i>System Info</div>
            <div style="display:flex;flex-direction:column;gap:10px;font-size:13px;">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:var(--gray-500);">Queue Driver</span>
                    <span class="badge badge-processing">Redis</span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:var(--gray-500);">Worker</span>
                    <span class="badge badge-completed">Supervisor</span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:var(--gray-500);">PHP Version</span>
                    <span style="font-weight:600;color:var(--gray-700);">{{ PHP_VERSION }}</span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:var(--gray-500);">Laravel</span>
                    <span style="font-weight:600;color:var(--gray-700);">{{ app()->version() }}</span>
                </div>
            </div>
        </div>

    </div>
</div>

@endsection
