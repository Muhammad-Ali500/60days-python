@extends('layouts.app')

@section('title', 'Dispatch Job')
@section('page-title', 'Dispatch New Job')
@section('page-subtitle', 'Create and queue a new background job')

@section('content')

<div style="max-width:720px;">
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-paper-plane" style="color:var(--primary);margin-right:8px;"></i>New Job</span>
            <a href="{{ route('jobs.index') }}" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
        <div class="card-body">
            <form action="{{ route('jobs.store') }}" method="POST">
                @csrf

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                    <div class="form-group" style="grid-column:1/-1;">
                        <label class="form-label">Job Name <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="name" class="form-control" value="{{ old('name') }}"
                               placeholder="e.g. Send Welcome Email, Generate Monthly Report..." required>
                        <div class="form-hint">A descriptive name to identify this job.</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Job Type <span style="color:var(--danger);">*</span></label>
                        <select name="type" class="form-control" required id="job-type">
                            @foreach(['general' => 'General Task', 'email' => 'Email', 'report' => 'Report Generation', 'import' => 'Data Import', 'export' => 'Data Export', 'notification' => 'Notification'] as $val => $label)
                                <option value="{{ $val }}" {{ old('type') === $val ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Target Queue <span style="color:var(--danger);">*</span></label>
                        <select name="queue" class="form-control" required>
                            @foreach(['default' => 'Default Queue', 'emails' => 'Email Queue', 'reports' => 'Reports Queue', 'imports' => 'Imports Queue', 'high' => 'High Priority', 'low' => 'Low Priority'] as $val => $label)
                                <option value="{{ $val }}" {{ old('queue') === $val ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                        <div class="form-hint">Jobs in <strong>high</strong> queue are processed first.</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Priority (0–10)</label>
                        <input type="number" name="priority" class="form-control" value="{{ old('priority', 0) }}" min="0" max="10">
                        <div class="form-hint">Higher = more important.</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Max Attempts</label>
                        <input type="number" name="max_attempts" class="form-control" value="{{ old('max_attempts', 3) }}" min="1" max="10">
                        <div class="form-hint">How many times to retry on failure.</div>
                    </div>
                </div>

                <!-- Dynamic payload section -->
                <div id="payload-section" style="margin-top:8px;">
                    <div class="form-group" id="payload-email" style="display:none;">
                        <label class="form-label">Recipient Email</label>
                        <input type="email" name="payload[recipient]" class="form-control" placeholder="user@example.com">
                    </div>
                    <div class="form-group" id="payload-report" style="display:none;">
                        <label class="form-label">Report Name</label>
                        <input type="text" name="payload[report_name]" class="form-control" placeholder="Monthly Sales Report">
                    </div>
                    <div class="form-group" id="payload-import" style="display:none;">
                        <label class="form-label">Filename</label>
                        <input type="text" name="payload[filename]" class="form-control" placeholder="data.csv">
                    </div>
                    <div class="form-group" id="payload-export" style="display:none;">
                        <label class="form-label">Export Format</label>
                        <select name="payload[format]" class="form-control" id="payload-export-field">
                            <option value="csv">CSV</option>
                            <option value="xlsx">Excel</option>
                            <option value="json">JSON</option>
                            <option value="pdf">PDF</option>
                        </select>
                    </div>
                    <div class="form-group" id="payload-notification" style="display:none;">
                        <label class="form-label">Channel</label>
                        <input type="text" name="payload[channel]" class="form-control" placeholder="all users / marketing segment...">
                    </div>
                </div>

                <div style="display:flex;gap:10px;margin-top:8px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Dispatch Job
                    </button>
                    <a href="{{ route('jobs.index') }}" class="btn btn-outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Info card -->
    <div class="card card-body" style="margin-top:16px;background:var(--primary-light);border-color:#c7d2fe;">
        <div style="font-weight:700;color:var(--primary-dark);margin-bottom:8px;"><i class="fas fa-circle-info"></i> How it works</div>
        <div style="font-size:13px;color:var(--gray-700);line-height:1.7;">
            Dispatched jobs are pushed to <strong>Redis</strong> and processed by <strong>Supervisor</strong>-managed workers.
            Jobs simulate real processing time and are tracked in the database.
            Failed jobs can be retried from the job list.
        </div>
    </div>
</div>

@push('scripts')
<script>
const typeSelect = document.getElementById('job-type');
const allPayloads = ['email','report','import','export','notification'];

function updatePayload() {
    allPayloads.forEach(t => {
        const el = document.getElementById('payload-' + t);
        if (el) el.style.display = 'none';
    });
    const selected = typeSelect.value;
    const el = document.getElementById('payload-' + selected);
    if (el) el.style.display = 'block';
}

typeSelect.addEventListener('change', updatePayload);
updatePayload();
</script>
@endpush
@endsection
