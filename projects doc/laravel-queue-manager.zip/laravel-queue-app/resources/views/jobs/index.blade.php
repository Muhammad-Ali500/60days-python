@extends('layouts.app')

@section('title', 'All Jobs')
@section('page-title', 'Job Queue')
@section('page-subtitle', 'Manage and monitor all queued jobs')

@section('content')

<!-- Stats Bar -->
<div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
    @foreach(['total' => ['all','var(--gray-500)'], 'pending' => ['pending','var(--warning)'], 'processing' => ['processing','var(--info)'], 'completed' => ['completed','var(--success)'], 'failed' => ['failed','var(--danger)']] as $key => $meta)
    <a href="{{ route('jobs.index', array_merge(request()->query(), ['status' => $key === 'total' ? null : $key])) }}"
       style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-radius:8px;text-decoration:none;background:#fff;border:1px solid var(--gray-200);font-size:13px;font-weight:600;color:{{ $meta[1] }};{{ request('status') == ($key === 'total' ? null : $key) ? 'border-color:'.$meta[1].';box-shadow:0 0 0 3px rgba(0,0,0,.04)' : '' }}">
        <span style="font-size:20px;font-weight:800;">{{ $stats[$key] }}</span>
        <span style="color:var(--gray-500);font-weight:500;text-transform:capitalize;">{{ $meta[0] }}</span>
    </a>
    @endforeach
</div>

<!-- Table Card -->
<div class="card">
    <!-- Filters -->
    <form method="GET" action="{{ route('jobs.index') }}">
        <div class="filters">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Search by name..." style="flex:1;min-width:160px;">
            <select name="status">
                <option value="">All Statuses</option>
                @foreach(['pending','processing','completed','failed'] as $s)
                    <option value="{{ $s }}" {{ request('status') === $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                @endforeach
            </select>
            <select name="type">
                <option value="">All Types</option>
                @foreach(['email','report','import','export','notification','general'] as $t)
                    <option value="{{ $t }}" {{ request('type') === $t ? 'selected' : '' }}>{{ ucfirst($t) }}</option>
                @endforeach
            </select>
            <select name="queue">
                <option value="">All Queues</option>
                @foreach(['default','emails','reports','imports','high','low'] as $q)
                    <option value="{{ $q }}" {{ request('queue') === $q ? 'selected' : '' }}>{{ ucfirst($q) }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
            <a href="{{ route('jobs.index') }}" class="btn btn-outline btn-sm"><i class="fas fa-xmark"></i></a>
        </div>
    </form>

    <!-- Bulk Actions -->
    <form action="{{ route('jobs.bulk-action') }}" method="POST" id="bulk-form">
        @csrf
        <div style="display:flex;align-items:center;gap:8px;padding:10px 20px;border-bottom:1px solid var(--gray-100);background:var(--gray-50);">
            <select name="action" class="form-control" style="width:auto;padding:5px 10px;font-size:13px;">
                <option value="delete">Delete Selected</option>
                <option value="retry">Retry Selected</option>
            </select>
            <button type="submit" class="btn btn-outline btn-sm" onclick="return confirm('Apply bulk action?')">
                <i class="fas fa-check"></i> Apply
            </button>
            <span style="font-size:12px;color:var(--gray-400);margin-left:4px;">
                {{ $tasks->total() }} jobs
            </span>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th style="width:36px;"><input type="checkbox" class="cb" onchange="toggleAll(this)"></th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Queue</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Attempts</th>
                        <th>Created</th>
                        <th style="text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($tasks as $task)
                    <tr>
                        <td><input type="checkbox" name="task_ids[]" value="{{ $task->id }}" class="cb job-cb"></td>
                        <td>
                            <div style="font-weight:600;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="{{ $task->name }}">{{ $task->name }}</div>
                            @if($task->error_message)
                                <div style="font-size:11px;color:var(--danger);margin-top:2px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="{{ $task->error_message }}">
                                    <i class="fas fa-exclamation"></i> {{ $task->error_message }}
                                </div>
                            @endif
                        </td>
                        <td><span class="badge badge-{{ $task->type }}">{{ $task->type }}</span></td>
                        <td><span class="queue-tag">{{ $task->queue }}</span></td>
                        <td>
                            @if($task->priority >= 8)
                                <span style="color:var(--danger);font-weight:700;">HIGH</span>
                            @elseif($task->priority >= 5)
                                <span style="color:var(--warning);font-weight:700;">MED</span>
                            @else
                                <span style="color:var(--gray-400);">{{ $task->priority }}</span>
                            @endif
                        </td>
                        <td>
                            <span class="badge badge-{{ $task->status }}">
                                @if($task->status === 'processing')<i class="fas fa-spinner fa-spin" style="font-size:9px;"></i> @endif
                                {{ $task->status }}
                            </span>
                        </td>
                        <td style="color:var(--gray-500);">{{ $task->attempts }}/{{ $task->max_attempts }}</td>
                        <td style="color:var(--gray-400);font-size:12px;">{{ $task->created_at->diffForHumans() }}</td>
                        <td style="text-align:right;">
                            <div style="display:flex;gap:4px;justify-content:flex-end;">
                                <a href="{{ route('jobs.show', $task) }}" class="btn btn-outline btn-sm" title="View"><i class="fas fa-eye"></i></a>
                                @if($task->isFailed())
                                <form action="{{ route('jobs.retry', $task) }}" method="POST" style="display:inline;">
                                    @csrf
                                    <button type="submit" class="btn btn-warning btn-sm" title="Retry"><i class="fas fa-rotate-right"></i></button>
                                </form>
                                @endif
                                <form action="{{ route('jobs.destroy', $task) }}" method="POST" style="display:inline;" class="delete-form">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="9">
                            <div class="empty">
                                <i class="fas fa-inbox"></i>
                                <h3>No jobs found</h3>
                                <p>Try adjusting filters or <a href="{{ route('jobs.create') }}">dispatch a new job</a>.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </form>

    <!-- Pagination -->
    @if($tasks->hasPages())
    <div class="pagination">
        @if($tasks->onFirstPage())
            <span class="page-link" style="opacity:.4;">&laquo;</span>
        @else
            <a href="{{ $tasks->previousPageUrl() }}" class="page-link">&laquo;</a>
        @endif

        @foreach($tasks->getUrlRange(max(1,$tasks->currentPage()-2), min($tasks->lastPage(),$tasks->currentPage()+2)) as $page => $url)
            <a href="{{ $url }}" class="page-link {{ $tasks->currentPage() === $page ? 'active' : '' }}">{{ $page }}</a>
        @endforeach

        @if($tasks->hasMorePages())
            <a href="{{ $tasks->nextPageUrl() }}" class="page-link">&raquo;</a>
        @else
            <span class="page-link" style="opacity:.4;">&raquo;</span>
        @endif
    </div>
    @endif
</div>
@endsection
