@extends('layouts.app')

@section('title', 'Job Detail')
@section('page-title', 'Job Detail')
@section('page-subtitle', 'View full details of the queued job')

@section('content')

<div style="max-width:800px;">

    <!-- Header -->
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
        <a href="{{ route('jobs.index') }}" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
        <span class="badge badge-{{ $task->status }}" style="font-size:13px;padding:6px 14px;">
            @if($task->status === 'processing')<i class="fas fa-spinner fa-spin"></i> @endif
            {{ ucfirst($task->status) }}
        </span>
        @if($task->isFailed())
        <form action="{{ route('jobs.retry', $task) }}" method="POST" style="margin-left:auto;">
            @csrf
            <button type="submit" class="btn btn-warning"><i class="fas fa-rotate-right"></i> Retry Job</button>
        </form>
        @endif
        <form action="{{ route('jobs.destroy', $task) }}" method="POST" class="delete-form" {{ $task->isFailed() ? '' : 'style=margin-left:auto;' }}>
            @csrf @method('DELETE')
            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
        </form>
    </div>

    <!-- Main Detail Card -->
    <div class="card" style="margin-bottom:16px;">
        <div class="card-header">
            <span class="card-title">
                <i class="fas fa-circle-info" style="color:var(--primary);margin-right:6px;"></i>
                {{ $task->name }}
            </span>
            <span style="font-size:12px;color:var(--gray-400);">#{{ $task->id }}</span>
        </div>
        <div class="card-body">
            <div class="detail-grid">
                <div class="detail-item">
                    <label>Job Type</label>
                    <span><span class="badge badge-{{ $task->type }}">{{ $task->type }}</span></span>
                </div>
                <div class="detail-item">
                    <label>Queue</label>
                    <span><span class="queue-tag"><i class="fas fa-server" style="font-size:9px;"></i> {{ $task->queue }}</span></span>
                </div>
                <div class="detail-item">
                    <label>Priority</label>
                    <span>{{ $task->priority }}</span>
                </div>
                <div class="detail-item">
                    <label>Attempts</label>
                    <span>{{ $task->attempts }} / {{ $task->max_attempts }}</span>
                </div>
                <div class="detail-item">
                    <label>Created At</label>
                    <span>{{ $task->created_at->format('Y-m-d H:i:s') }}</span>
                </div>
                <div class="detail-item">
                    <label>Updated At</label>
                    <span>{{ $task->updated_at->format('Y-m-d H:i:s') }}</span>
                </div>
                @if($task->started_at)
                <div class="detail-item">
                    <label>Started At</label>
                    <span>{{ $task->started_at->format('Y-m-d H:i:s') }}</span>
                </div>
                @endif
                @if($task->completed_at)
                <div class="detail-item">
                    <label>Completed At</label>
                    <span>{{ $task->completed_at->format('Y-m-d H:i:s') }}</span>
                </div>
                @endif
                @if($task->duration)
                <div class="detail-item">
                    <label>Duration</label>
                    <span>{{ $task->duration }}</span>
                </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Payload -->
    @if($task->payload)
    <div class="card" style="margin-bottom:16px;">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-code" style="color:var(--info);margin-right:6px;"></i>Payload</span>
        </div>
        <div class="card-body">
            <pre style="background:var(--gray-900);color:#a5f3fc;padding:16px;border-radius:8px;font-size:13px;overflow:auto;line-height:1.6;">{{ json_encode($task->payload, JSON_PRETTY_PRINT) }}</pre>
        </div>
    </div>
    @endif

    <!-- Result -->
    @if($task->result)
    <div class="card" style="margin-bottom:16px;">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-circle-check" style="color:var(--success);margin-right:6px;"></i>Result</span>
        </div>
        <div class="card-body">
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ $task->result }}</div>
        </div>
    </div>
    @endif

    <!-- Error -->
    @if($task->error_message)
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-triangle-exclamation" style="color:var(--danger);margin-right:6px;"></i>Error</span>
        </div>
        <div class="card-body">
            <pre style="background:#1e0a0a;color:#fca5a5;padding:16px;border-radius:8px;font-size:13px;overflow:auto;line-height:1.6;white-space:pre-wrap;">{{ $task->error_message }}</pre>
        </div>
    </div>
    @endif

</div>
@endsection
