<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Queue Manager') — Laravel Queue Manager</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --primary-light: #e0e7ff;
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
            --dark: #0f172a;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --gray-900: #0f172a;
            --sidebar-w: 260px;
            --radius: 12px;
            --shadow: 0 1px 3px rgba(0,0,0,.08), 0 1px 2px rgba(0,0,0,.06);
            --shadow-md: 0 4px 6px -1px rgba(0,0,0,.1), 0 2px 4px -1px rgba(0,0,0,.06);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,.1), 0 4px 6px -2px rgba(0,0,0,.05);
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--gray-50);
            color: var(--gray-800);
            display: flex;
            min-height: 100vh;
        }

        /* ── Sidebar ── */
        .sidebar {
            width: var(--sidebar-w);
            background: var(--gray-900);
            color: #fff;
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0; left: 0; bottom: 0;
            z-index: 100;
            overflow-y: auto;
        }

        .sidebar-brand {
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255,255,255,.08);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar-brand-icon {
            width: 40px; height: 40px;
            background: var(--primary);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .sidebar-brand-text { font-size: 15px; font-weight: 700; line-height: 1.2; }
        .sidebar-brand-sub  { font-size: 11px; color: var(--gray-400); font-weight: 400; }

        .sidebar-section { padding: 16px 12px 8px; font-size: 10px; text-transform: uppercase; letter-spacing: .08em; color: var(--gray-500); font-weight: 600; }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 8px;
            margin: 2px 8px;
            text-decoration: none;
            color: var(--gray-400);
            font-size: 14px;
            font-weight: 500;
            transition: all .2s;
        }

        .nav-item:hover { background: rgba(255,255,255,.06); color: #fff; }
        .nav-item.active { background: var(--primary); color: #fff; }
        .nav-item i { width: 18px; text-align: center; font-size: 13px; }

        .nav-badge {
            margin-left: auto;
            background: var(--danger);
            color: #fff;
            font-size: 10px;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 99px;
            min-width: 18px;
            text-align: center;
        }

        .sidebar-footer {
            margin-top: auto;
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,.08);
            font-size: 12px;
            color: var(--gray-500);
            text-align: center;
        }

        /* ── Main ── */
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .topbar {
            background: #fff;
            border-bottom: 1px solid var(--gray-200);
            padding: 0 28px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 50;
        }

        .topbar-title { font-size: 18px; font-weight: 700; color: var(--gray-900); }
        .topbar-subtitle { font-size: 13px; color: var(--gray-500); margin-top: 1px; }

        .topbar-actions { display: flex; align-items: center; gap: 12px; }

        .page-content { padding: 28px; flex: 1; }

        /* ── Cards ── */
        .card {
            background: #fff;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--gray-200);
        }

        .card-header {
            padding: 16px 20px;
            border-bottom: 1px solid var(--gray-100);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-title { font-size: 15px; font-weight: 600; color: var(--gray-900); }
        .card-body { padding: 20px; }

        /* ── Stat Cards ── */
        .stats-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px; }

        .stat-card {
            background: #fff;
            border-radius: var(--radius);
            padding: 20px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow);
            display: flex;
            align-items: flex-start;
            gap: 14px;
        }

        .stat-icon {
            width: 46px; height: 46px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }

        .stat-icon.purple  { background: #ede9fe; color: var(--primary); }
        .stat-icon.blue    { background: #dbeafe; color: var(--info); }
        .stat-icon.orange  { background: #fef3c7; color: var(--warning); }
        .stat-icon.green   { background: #dcfce7; color: var(--success); }
        .stat-icon.red     { background: #fee2e2; color: var(--danger); }

        .stat-number { font-size: 26px; font-weight: 700; color: var(--gray-900); line-height: 1; }
        .stat-label  { font-size: 12px; color: var(--gray-500); margin-top: 4px; font-weight: 500; }

        /* ── Buttons ── */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: all .15s;
            white-space: nowrap;
        }

        .btn-primary { background: var(--primary); color: #fff; }
        .btn-primary:hover { background: var(--primary-dark); }
        .btn-success { background: var(--success); color: #fff; }
        .btn-danger  { background: var(--danger); color: #fff; }
        .btn-warning { background: var(--warning); color: #fff; }
        .btn-outline { background: transparent; color: var(--gray-700); border: 1px solid var(--gray-300); }
        .btn-outline:hover { background: var(--gray-50); }
        .btn-sm { padding: 5px 10px; font-size: 12px; }

        /* ── Badges ── */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 10px;
            border-radius: 99px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .03em;
        }

        .badge-pending    { background: #fef9c3; color: #854d0e; }
        .badge-processing { background: #dbeafe; color: #1e40af; }
        .badge-completed  { background: #dcfce7; color: #166534; }
        .badge-failed     { background: #fee2e2; color: #991b1b; }
        .badge-email      { background: #ede9fe; color: #6d28d9; }
        .badge-report     { background: #e0f2fe; color: #075985; }
        .badge-import     { background: #fef3c7; color: #92400e; }
        .badge-export     { background: #d1fae5; color: #065f46; }
        .badge-general    { background: var(--gray-100); color: var(--gray-600); }
        .badge-notification { background: #ffe4e6; color: #9f1239; }

        /* ── Table ── */
        .table-wrap { overflow-x: auto; }

        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th { padding: 10px 14px; text-align: left; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .05em; color: var(--gray-500); background: var(--gray-50); border-bottom: 1px solid var(--gray-200); }
        td { padding: 12px 14px; border-bottom: 1px solid var(--gray-100); vertical-align: middle; color: var(--gray-700); }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: var(--gray-50); }

        /* ── Forms ── */
        .form-group { margin-bottom: 18px; }
        .form-label { display: block; font-size: 13px; font-weight: 600; color: var(--gray-700); margin-bottom: 6px; }
        .form-control {
            width: 100%;
            padding: 9px 12px;
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
            color: var(--gray-800);
            transition: border .15s, box-shadow .15s;
            background: #fff;
        }
        .form-control:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(99,102,241,.12); }
        .form-hint { font-size: 11px; color: var(--gray-400); margin-top: 4px; }

        /* ── Alerts ── */
        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert-error   { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert-info    { background: #dbeafe; color: #1e40af; border: 1px solid #bfdbfe; }

        /* ── Filters ── */
        .filters {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            padding: 14px 20px;
            border-bottom: 1px solid var(--gray-100);
        }

        .filters select, .filters input {
            padding: 7px 10px;
            border: 1px solid var(--gray-300);
            border-radius: 7px;
            font-size: 13px;
            font-family: inherit;
            background: #fff;
        }

        /* ── Pagination ── */
        .pagination { display: flex; gap: 4px; align-items: center; justify-content: center; padding: 16px; }
        .page-link {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            text-decoration: none;
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }
        .page-link:hover { background: var(--gray-100); }
        .page-link.active { background: var(--primary); color: #fff; border-color: var(--primary); }

        /* ── Progress bar ── */
        .progress { height: 6px; background: var(--gray-200); border-radius: 99px; overflow: hidden; }
        .progress-bar { height: 100%; border-radius: 99px; transition: width .5s; }
        .progress-success { background: var(--success); }
        .progress-danger  { background: var(--danger); }

        /* ── Queue indicator ── */
        .queue-tag {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 8px;
            border-radius: 5px;
            font-size: 11px;
            font-weight: 600;
            background: var(--gray-100);
            color: var(--gray-600);
        }

        /* ── Detail ── */
        .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .detail-item label { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: var(--gray-400); font-weight: 600; display: block; margin-bottom: 4px; }
        .detail-item span  { font-size: 14px; color: var(--gray-800); font-weight: 500; }

        /* ── Checkbox ── */
        .cb { width: 15px; height: 15px; cursor: pointer; }

        /* ── Empty state ── */
        .empty { text-align: center; padding: 60px 20px; color: var(--gray-400); }
        .empty i { font-size: 48px; margin-bottom: 16px; display: block; }
        .empty h3 { font-size: 16px; color: var(--gray-600); margin-bottom: 8px; }
        .empty p  { font-size: 13px; }

        /* ── Responsive ── */
        @media (max-width: 1100px) {
            .stats-grid { grid-template-columns: repeat(3, 1fr); }
        }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .main { margin-left: 0; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
    @stack('styles')
</head>
<body>

<!-- Sidebar -->
<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="sidebar-brand-icon"><i class="fas fa-layer-group"></i></div>
        <div>
            <div class="sidebar-brand-text">Queue Manager</div>
            <div class="sidebar-brand-sub">Laravel + Redis</div>
        </div>
    </div>

    <div class="sidebar-section">Main</div>
    <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
        <i class="fas fa-chart-pie"></i> Dashboard
    </a>
    <a href="{{ route('jobs.index') }}" class="nav-item {{ request()->routeIs('jobs.*') ? 'active' : '' }}">
        <i class="fas fa-list-check"></i> All Jobs
        @php $failed = \App\Models\QueueTask::where('status','failed')->count(); @endphp
        @if($failed > 0)
            <span class="nav-badge">{{ $failed }}</span>
        @endif
    </a>
    <a href="{{ route('jobs.create') }}" class="nav-item {{ request()->routeIs('jobs.create') ? 'active' : '' }}">
        <i class="fas fa-plus-circle"></i> Dispatch Job
    </a>

    <div class="sidebar-section">Queues</div>
    <a href="{{ route('jobs.index', ['queue' => 'default']) }}" class="nav-item">
        <i class="fas fa-inbox"></i> Default
    </a>
    <a href="{{ route('jobs.index', ['queue' => 'emails']) }}" class="nav-item">
        <i class="fas fa-envelope"></i> Emails
    </a>
    <a href="{{ route('jobs.index', ['queue' => 'reports']) }}" class="nav-item">
        <i class="fas fa-file-chart-column"></i> Reports
    </a>
    <a href="{{ route('jobs.index', ['queue' => 'high']) }}" class="nav-item">
        <i class="fas fa-bolt"></i> High Priority
    </a>

    <div class="sidebar-section">System</div>
    <a href="/api/queue/stats" target="_blank" class="nav-item">
        <i class="fas fa-code"></i> REST API
    </a>

    <div class="sidebar-footer">
        <i class="fas fa-circle" style="color:var(--success);font-size:8px;"></i>
        Redis Connected &bull; Supervisor Active
    </div>
</aside>

<!-- Main Content -->
<main class="main">
    <div class="topbar">
        <div>
            <div class="topbar-title">@yield('page-title', 'Dashboard')</div>
            <div class="topbar-subtitle">@yield('page-subtitle', 'Queue Management System')</div>
        </div>
        <div class="topbar-actions">
            <a href="{{ route('jobs.create') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> Dispatch Job
            </a>
        </div>
    </div>

    <div class="page-content">
        @if(session('success'))
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> {{ session('error') }}</div>
        @endif
        @if($errors->any())
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i>
                <div>@foreach($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>
            </div>
        @endif

        @yield('content')
    </div>
</main>

<script>
// Auto-refresh every 10 seconds on dashboard
@if(request()->routeIs('dashboard'))
setTimeout(() => location.reload(), 10000);
@endif

// Select all checkboxes
function toggleAll(source) {
    document.querySelectorAll('.job-cb').forEach(cb => cb.checked = source.checked);
}

// Confirm delete
document.querySelectorAll('.delete-form').forEach(f => {
    f.addEventListener('submit', e => {
        if (!confirm('Delete this job? This cannot be undone.')) e.preventDefault();
    });
});
</script>
@stack('scripts')
</body>
</html>
